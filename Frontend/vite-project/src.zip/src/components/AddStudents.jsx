import React, { useState } from 'react';
import { TextField, Button, Paper, Typography } from '@mui/material';
import { Message } from '@mui/icons-material';

// function handleClick() {
//   alert('Data Added Successfully');
// }

const AddDataForm = ({ onAdd }) => {
  var [formData, setFormData] = useState({
    id: '',
    name: '',
    age: '',
    email: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({...formData,[e.target.name]: value, });
  };

  const handleSubmit = (e) => { e.preventDefault();
    // onAdd(formData);
    setFormData({
      id: '',
      name: '',
      age: '',
      email: '',
    });
    alert('Data Added Successfully');
  };

  return (
    <Paper style={{ padding: '1rem', marginBottom: '2rem' }}>
      <Typography variant="h6" component="div">
        Add New Data
      </Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          name="id"
          label="ID"
          value={formData.id}
          onChange={handleChange}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          name="name"
          label="Name"
          value={formData.name}
          onChange={handleChange}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          name="age"
          label="Age"
          value={formData.age}
          onChange={handleChange}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          name="email"
          label="Email"
          value={formData.email}
          onChange={handleChange}
          fullWidth
          margin="normal"
          required
        />
        <Button type="submit" variant="contained" color="primary" style={{ marginTop: '1rem' }} onClick={handleSubmit}>
          Add
        </Button>
      </form>
    </Paper>
  );
};

export default AddDataForm;
