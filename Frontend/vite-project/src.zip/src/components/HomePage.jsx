import React from 'react';
import { AppBar, Toolbar, Typography, Container, Grid, Paper, Button } from '@mui/material';
import './HomePage.css'; 

const HomePage = () => {
  return (
    <div className="background">
      <Container maxWidth="md" className="content-container">
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Paper elevation={3} className="paper-style">
              <Typography variant="h4" component="h1" gutterBottom className="welcome-text">
               EMPLOYEE DATA
              </Typography>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
};

export default HomePage;
